/*
	Copyright (c) 2004-2005, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/community/licensing.shtml
*/

dojo.provide("dojo.collections.ByteArray");
dojo.require("dojo.collections.Collections");

//	the following is an implementation of a 32 bit Byte Array.
dojo.collections.ByteArray = function(s){



}
