/*
	Copyright (c) 2004-2006, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/community/licensing.shtml
*/

/*<?xml version="1.0" encoding="UTF-8" ?>*/
({
		invalidMessage: "* 入力したデータに該当するものがありません。",
		missingMessage: "* 入力が必須です。",
		rangeMessage: "* 入力した数値は選択範囲外です。"
})
